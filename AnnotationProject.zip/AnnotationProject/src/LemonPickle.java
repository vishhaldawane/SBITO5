import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

@Retention(RUNTIME)
@Target(TYPE)
public @interface LemonPickle {

	String madeBy();

	int shelfLife();

}
/*
 
  class LemonPickle
  {
  		String madeBy;
  }
  
  LemonPickle lp = new LemonPickle();
  lp.setMadeBy("Reeta");
  
  
  
 */
