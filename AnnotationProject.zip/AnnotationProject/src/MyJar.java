
/*this is for the lemon pickle*/

@LemonPickle(madeBy="Reeta", shelfLife=4)
public class MyJar {

	int i;
	
	void pickle() {
		System.out.println("it has pickle...");
	}
	
}
