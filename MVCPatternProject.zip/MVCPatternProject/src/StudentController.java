
public class StudentController {//CONTROLLER
	private Student     model;
	private StudentView view;
	
	public StudentController(Student model, StudentView view) {
		super();
		this.model = model;
		this.view = view;
	}
	
	void setStudentName(String name) {
		model.setName(name);
	}
	String getStudentName() {
		return model.getName();
	}
	
	void setStudentRollNumber(int roll) {
		model.setRollNumber(roll);
	}
	int getStudentRollNumber() {
		return model.getRollNumber();
	}
	void updateView() {
		view.printStudentDetails(model);
	}
}
