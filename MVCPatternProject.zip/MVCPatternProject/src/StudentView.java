
public class StudentView { //VIEW|JSP
	public void printStudentDetails(Student x)
	{
		System.out.println("+----STUDENT VIEW-----");
		System.out.println("| Roll Number  : "+x.getRollNumber());
		System.out.println("| Student Name : "+x.getName());
		System.out.println("+----------------------");
	}
}
