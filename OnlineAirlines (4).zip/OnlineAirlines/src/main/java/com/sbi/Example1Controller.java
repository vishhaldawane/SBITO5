package com.sbi;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.mvc.Controller;
import org.springframework.web.servlet.view.InternalResourceView;

			//CONTROLLER
public class Example1Controller implements Controller {
	public ModelAndView handleRequest(HttpServletRequest req,
			HttpServletResponse resp) throws Exception {
		View view = new InternalResourceView("example1.jsp");//VIEW
		ModelAndView mav = new ModelAndView(view);
		mav.addObject("mymessage","Welcome to Spring MVC Controller1");//MODEL
		return mav;
		
	}
}
