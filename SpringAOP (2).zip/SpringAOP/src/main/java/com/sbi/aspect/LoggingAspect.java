package com.sbi.aspect;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

//LoggingAspect logAsp = new LoggingAspect();
//logAsp.logIt();

@Aspect
@Component
public class LoggingAspect {
	
	
	
	public LoggingAspect() {
		super();
		System.out.println("LoggingAspect() ctor...");
	}

	@Around("execution(public * apply*(..))")
	public void logIt(ProceedingJoinPoint joinPoint) {
		StopWatch watch = new StopWatch();
		watch.start();
		System.out.println("[ Logging code executed ");
		/*Object proxyObject = joinPoint.getThis();
		Object targetBean  = joinPoint.getTarget();*/
		try {
			Object result = joinPoint.proceed();
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		watch.stop();
		Signature sign = joinPoint.getSignature();
		String methodName = sign.getName();
		
		System.out.println("  Method to run : "+methodName + " ] "+(watch.getTotalTimeMillis()));
		/*try {
			Method method = targetBean.getClass().getDeclaredMethod(methodName, null);
			long timeBefore = System.currentTimeMillis();
			Object result = method.invoke(targetBean);
			System.out.println("Time diff : "+(System.currentTimeMillis() - timeBefore));
			
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

	}
}
