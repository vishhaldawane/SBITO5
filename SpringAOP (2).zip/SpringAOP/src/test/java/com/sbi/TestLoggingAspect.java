package com.sbi;



import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Calendar;

import org.junit.jupiter.api.Test;

// C, C++, Effective C++, STL with C++
// Core Java, Servlets JSP
// Spring Hibernate/JPA
// Oracle SQL/PLSQL
// Unix Shell Scripting - 256 trainings - 54 MNCs - 5000 hours +
// DevOps Jenkin CICD pipeline
// Angular 
// React
// Design Patterns
// JFSD

import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.service.CustomerServiceImpl;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations= {"classpath:myspring.xml"} )
public class TestLoggingAspect {

	@Autowired
	CustomerServiceImpl custService;
	
	
	@Test
	public void testLogging() {

		/*Method method[] = this.getClass().getDeclaredMethods();
		for (Method theMethod : method) {
			long timeBefore = System.currentTimeMillis();
			try {
				Object result = theMethod.invoke(theMethod);
			} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Time diff : "+(System.currentTimeMillis() - timeBefore));	
		}*/
		
		
		
		
		
		custService.applyForChequeBook();
		custService.stopCheque(444);
		custService.applyForCreditCard("Jack", 5500);
		custService.getBalance();
		
	}
}
