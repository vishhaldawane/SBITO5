package com.sbi.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import com.sbi.service.BusinessException;

@Aspect
@Component
public class ExceptionHandler {

	@AfterThrowing(pointcut = "execution(* someBusinessMethod(..))",throwing = "ex")
	public void handleException(JoinPoint jp, RuntimeException ex) {
		System.out.println("Routine exception handling here...");
		System.out.println("Let's see who has raised the exception");
		System.out.println("========================");
		System.out.println(jp.getSignature().getName());
		System.out.println("========================");
		throw new BusinessException(jp.getSignature().getName()+" got some exception");
	}
}
