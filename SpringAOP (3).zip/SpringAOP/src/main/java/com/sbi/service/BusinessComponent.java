package com.sbi.service;

import org.springframework.stereotype.Component;

@Component
public class BusinessComponent implements BusinessInterface {
	public void someBusinessMethod() throws BusinessException {
		System.out.println(">> in someBusinessMethod <<");
		throw new RuntimeException("Some Runtime exception occurred...");
	}
}
