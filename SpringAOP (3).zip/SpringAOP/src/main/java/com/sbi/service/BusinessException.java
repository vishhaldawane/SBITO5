package com.sbi.service;

public class BusinessException extends RuntimeException {

	public BusinessException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
