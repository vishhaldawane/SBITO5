package com.sbi.service;

import org.springframework.stereotype.Component;

@Component
public interface BusinessInterface {
	public void someBusinessMethod() throws BusinessException;
}
