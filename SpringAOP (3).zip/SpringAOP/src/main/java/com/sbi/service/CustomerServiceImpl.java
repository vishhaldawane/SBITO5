package com.sbi.service;

import org.springframework.stereotype.Service;

import com.sbi.aspect.LoggingAspect;

@Service
public class CustomerServiceImpl {
	
		public void applyForChequeBook() {
			
			System.out.println("Applying for the cheque book : ");
		}
		
		public void stopCheque(long acno) {
			System.out.println("Stopping the cheque of account number :  "+acno);
		}

		public void applyForCreditCard(String name, double salary) {
		
			System.out.println("Applying for CreditCard.... ");
		}
		
		public double getBalance() {
			System.out.println("Returning Balance .... ");
			return 999999;
		}
}

