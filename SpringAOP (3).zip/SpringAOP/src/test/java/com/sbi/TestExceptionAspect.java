package com.sbi;



import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Calendar;

import org.junit.jupiter.api.Test;

// C, C++, Effective C++, STL with C++
// Core Java, Servlets JSP
// Spring Hibernate/JPA
// Oracle SQL/PLSQL
// Unix Shell Scripting - 256 trainings - 54 MNCs - 5000 hours +
// DevOps Jenkin CICD pipeline
// Angular 
// React
// Design Patterns
// JFSD

import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.service.BusinessInterface;
import com.sbi.service.CustomerServiceImpl;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations= {"classpath:myspring.xml"} )
public class TestExceptionAspect {
	@Autowired
	BusinessInterface businessInterface;
	
	@Test
	public void testException() {
		try {
			businessInterface.someBusinessMethod();
		}
		catch(Exception e) {
			System.out.println("Test client caught exception : "+e);
		}
	}
}
