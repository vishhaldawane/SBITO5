import java.lang.annotation.Annotation;
import java.lang.reflect.Field;

public class JarTest {
	public static void main(String[] args) {
		
		//EVERY INSTANCE OF AN "Object CLASS" (11 METHODS )
		
		//GOT A METHOD CALLED AS getClass();
		
		//THAT RETURNS AN instance OF CLASS Class
		
		MyJar myjar = new MyJar();
		
		Class theMirror = myjar.getClass(); //RT TI
		
		
		
		
		
		Annotation anno[] = theMirror.getAnnotations();
		
		for (Annotation an : anno) {
			System.out.println("annotation name is : "+an);
			if ( an instanceof LemonPickle) {
				
				LemonPickle lp = (LemonPickle) an;
				System.out.println("made by     : "+lp.madeBy());
				System.out.println("shelft life : "+lp.shelfLife());
				
				if(lp.shelfLife() > 3 ) {
					System.out.println("Pickle is expired...");
				}
				else {
					System.out.println("Pickle is eatable...");
				}
			}
		}
		
		System.out.println("----------------");
		Field fields [] = theMirror.getDeclaredFields();

		for (Field field : fields) {
			System.out.println("Field name is : "+field.getName());
			
			Annotation annos[] = field.getAnnotations();
			
			for (Annotation an : annos) {
				System.out.println("annotation name is : "+an);
				if ( an instanceof JarCapacity) {
					
					JarCapacity jp = (JarCapacity) an;
					System.out.println("kg      : "+jp.kg());
				}
			}
		}
	}
	
}
