
/*this is for the lemon pickle*/

@LemonPickle( shelfLife=4)
public class MyJar {

	@JarCapacity(kg=1)
	int capacity;


	
	
	void pickle() {
		System.out.println("it has pickle...");
	}
	
}

// https://github.com/vishhaldawane/SBITO5