package com.sbi;

public class Car {

	public Car(Engine e) {
		System.out.println("Car constructor...");
	}
	public void drive() {
		System.out.println("Driving the car....");
	}
}

