// http://github.com/vishhaldawane

package com.sbi;
public class CarFactory {
	public Car getCar() {
		Piston p = new Piston();
		Engine e = new Engine(p);
		Car car = new Car(e);
		return car;
	}
	
	public Car getCar(String hint) {
		Car car =null;
		if(hint.equalsIgnoreCase("electric")) {
			Piston p = new Piston();
			ElectricEngine electEng = new ElectricEngine(p);
			car = new ElectricCar(electEng);
			
		}
		return car;
	}
}
