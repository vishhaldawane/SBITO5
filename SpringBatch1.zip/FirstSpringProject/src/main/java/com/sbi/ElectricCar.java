package com.sbi;

public class ElectricCar extends Car {

	public ElectricCar (ElectricEngine e) {
		super(e);
		System.out.println("ElectricCar constructor...");
	}
	public void drive() {
		System.out.println("Driving the Electric Car....");
	}
}
