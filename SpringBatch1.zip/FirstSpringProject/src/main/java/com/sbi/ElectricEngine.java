package com.sbi;

public class ElectricEngine extends Engine  { 
	
	public ElectricEngine(Piston p) {
		super(p);
		System.out.println("ElectricEngine ctor....");
	}
}