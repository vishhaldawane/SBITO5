package com.sbi;

public class Engine {

	Engine(Piston pist) {
		System.out.println("Engine(Piston) ctor...");
	}
	
	void startTheEngine() {
		System.out.println("Starting the engine...");
	}
}

