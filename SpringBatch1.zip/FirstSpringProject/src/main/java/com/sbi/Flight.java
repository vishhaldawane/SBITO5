package com.sbi;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
@Component("fli")
@Scope("prototype")
public class Flight {
	public Flight() {
		System.out.println("Flight() ctor...");
	}
}

@Component
class FlightRepository {
	public FlightRepository() {
		System.out.println("FlightRepository() ctor...");
	}
}

@Component
class FlightService {
	public FlightService () {
		System.out.println("FlightService () ctor...");
	}
}

@Component
class FlightController {
	public FlightController () {
		System.out.println("FlightController () ctor...");
	}
}