package com.sbi;

public class FlightEnquiry {

	public FlightEnquiry() { //explicit no-arg constructor
		System.out.println("FlightEnquiry()..."+this);
	}
	public void findFlights() {
		System.out.println("Finding flights...."+this);
	}
}
