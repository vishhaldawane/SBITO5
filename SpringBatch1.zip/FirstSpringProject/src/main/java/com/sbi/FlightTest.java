package com.sbi;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class FlightTest {
	public static void main(String[] args) {
		//ctrl+shift+m
		System.out.println("=> Creating container....");
ApplicationContext ctx = 
new ClassPathXmlApplicationContext("myflights.xml");
		System.out.println("=> Created container....");

		FlightEnquiry flightEnq1 = (FlightEnquiry) ctx.getBean("fe");
		FlightEnquiry flightEnq2 = (FlightEnquiry) ctx.getBean("fe");
		FlightEnquiry flightEnq3 = (FlightEnquiry) ctx.getBean("fe");
		flightEnq1.findFlights();

		FlightTicket ft1 = (FlightTicket )ctx.getBean("ft");
		FlightTicket ft2 = (FlightTicket )ctx.getBean("ft");
		FlightTicket ft3 = (FlightTicket )ctx.getBean("ft");

		System.out.println("ft1 :"+ft1);
		System.out.println("ft2 :"+ft2);
		System.out.println("ft3 :"+ft3);
		
	}

}
