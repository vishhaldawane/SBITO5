package com.sbi;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class FlightTest2 {
	public static void main(String[] args) {
		//ctrl+shift+m
		System.out.println("=> Creating container....");
ApplicationContext ctx = 
new ClassPathXmlApplicationContext("myAnnoFlights.xml");
		System.out.println("=> Created container....");

		Flight theFlight = (Flight) ctx.getBean(Flight.class);
		
		System.out.println("theFlight  :"+theFlight);
		
		Flight theFlight2 = (Flight) ctx.getBean("fli");
		
		System.out.println("theFlight2 :"+theFlight2);
		
	}

}
