package com.sbi;

public class FlightTicket {

	public FlightTicket () {
		System.out.println("FlightTicket () ctor...");
	}
	public void ticketDetails() {
		
	}
}
