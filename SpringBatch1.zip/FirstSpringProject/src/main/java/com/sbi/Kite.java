package com.sbi;

public class Kite {

	static int x;
	
}

class Test
{
	public static void main(String[] args) {
		
		
		
	}
}
