package com.sbi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
//https://github.com/vishhaldawane/SBITO4/
//search for hsqldb.txt
	
@Component
public class MyCar {
	
	@Autowired
	MyEngine me;
	
	/*@Autowired
	public MyCar(MyEngine e) {
		super();
		me = e;
		System.out.println("MyCar(MyEngine) ctr..");
	}
	
	@Autowired
	public void setEngine(MyEngine e) {
		System.out.println("Car setEngine(MyEngine) invoked...");
		me = e;
	}*/
	public void drive() {
		me.startTheEngine();
		System.out.println("Driving the car....");
		
	}
}

