package com.sbi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MyEngine {
	
	@Autowired
	MyPiston pist;
	
	/*@Autowired
	public MyEngine(MyPiston p) {
		super();
		pist = p;
		System.out.println("MyEngine(MyPiston) ctr..");
	}
	
	@Autowired
	public void setPiston(MyPiston p) {
		System.out.println("Engine setPiston(MyPiston) invoked...");
		pist = p;
	}*/
	
	void startTheEngine() {
		pist.ignite();
		System.out.println("Starting the engine...");
	}
}

