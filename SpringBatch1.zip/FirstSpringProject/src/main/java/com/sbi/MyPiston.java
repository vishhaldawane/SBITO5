package com.sbi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class MyPiston {
	
	String name;
	
	@Autowired
	public MyPiston() { 
		super(); 
		System.out.println("MyPiston() ctr..");
		//name=str;
	}
	
	@Value("TwinSpark")
	public void setName(String str) {
		System.out.println("MyPiston setName(String) invoked...."+this);
		name=str;
	}
	public void ignite( ) {
		System.out.println("Igntiting the piston...."+name);
	}
}
