package com.sbi;

public class Piston {
	
	public Piston() {
		System.out.println("Piston() ctor...."+this);
	}
	public void ignite( ) {
		System.out.println("Igntiting the piston....");
	}
}
