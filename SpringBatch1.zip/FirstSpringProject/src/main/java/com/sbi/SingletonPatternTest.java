package com.sbi;

public class SingletonPatternTest {
	public static void main(String[] args) {
		
		Kitchen kitchen1 = Kitchen.getKitchen();
		Kitchen kitchen2 = Kitchen.getKitchen();
		Kitchen kitchen3 = Kitchen.getKitchen();
		
		System.out.println("kitchen1 : "+kitchen1);
		System.out.println("kitchen2 : "+kitchen2);
		System.out.println("kitchen3 : "+kitchen3);
		
	}
}

class Kitchen
{
	private static Kitchen kitchenObject; //single copy
	
	private Kitchen() {
		System.out.println("Kitchen() ctor...");
	}
	public static Kitchen getKitchen() {
		if (kitchenObject == null) //evaluated to TRUE only once 
			kitchenObject = new Kitchen();
		
		return kitchenObject;
	}
}
