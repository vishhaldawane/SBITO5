package com.sbi;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//DI - Dependency Injection
//Inversion of Control - IoC

public class UseCar {
	public static void main(String[] args) {
		/*Piston pist1 = new Piston();
		Engine eng1 = new Engine(pist1);
		Car myCar1 = new Car(eng1); //
				myCar1.drive();

		CarFactory carFactory = new CarFactory();
				Car myCar3 = 
						carFactory.getCar("electricCar");
				myCar3.drive();

		Piston pist2 = new Piston();
		Engine eng2 = new Engine(pist2);
		Car myCar2 = new Car(eng2);
				myCar2.drive();
		*/
		System.out.println("creating container...");		
		ApplicationContext myContext = new ClassPathXmlApplicationContext("myspring.xml");
		System.out.println("container...created");
		
		//eager loading
		
		System.out.println("getting a Car bean...");
		Car myCar1 = (Car) myContext.getBean("mycar1");
		Car myCar2 = (Car) myContext.getBean("mycar1");
		Car myCar3 = (Car) myContext.getBean("mycar1");
		
		System.out.println("myCar1 : "+myCar1.hashCode());
		System.out.println("myCar2 : "+myCar2.hashCode());
		System.out.println("myCar3 : "+myCar3.hashCode());
		System.out.println("got the Car bean...");
		
				
	}

}
