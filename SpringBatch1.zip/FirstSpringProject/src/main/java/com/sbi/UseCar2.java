package com.sbi;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//DI - Dependency Injection
//Inversion of Control - IoC

public class UseCar2 {
	public static void main(String[] args) {
		
		System.out.println("=> creating container...");		
		ApplicationContext myContext = new ClassPathXmlApplicationContext("myCarSetter.xml");
		System.out.println("=> container...created");
		
		//eager loading
		
		System.out.println("getting a Car bean...");
		MyCar myCar1 = (MyCar) myContext.getBean("myCar");
		
		myCar1.drive();
		
				
	}

}
