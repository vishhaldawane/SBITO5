
public class StudentMVCTest {
	public static void main(String[] args) {
		Student model = new Student(101,"Jack");
		StudentView view = new StudentView();

		StudentController studentController =
				new StudentController(model,view);
		studentController.updateView();
		  studentController.setStudentRollNumber(123);
		  studentController.setStudentName("Jackson");
		studentController.updateView();
	}
}
