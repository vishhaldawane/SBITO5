package com.sbi;

import java.util.ArrayList;
import java.util.List;

import org.apache.tomcat.util.net.ApplicationBufferHandler;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

			//CONTROLLER
@Controller
public class Example3Controller {

	List<Flight> listOfFlights = new ArrayList<Flight>();
	
	public Example3Controller() {
		System.out.println("Example3Controller ctor...");
		
		Flight flight1 = new Flight();
		Flight flight2 = new Flight();
		Flight flight3 = new Flight();
		
		flight1.setFlightNumber(101);
		flight1.setFlightName("British Airways");
		flight1.setFlightSource("Mumbai");
		flight1.setFlightDestination("London");
		
		flight2.setFlightNumber(102);
		flight2.setFlightName("Air France");
		flight2.setFlightSource("Mumbai");
		flight2.setFlightDestination("Paris");
		
		flight3.setFlightNumber(103);
		flight3.setFlightName("Air America");
		flight3.setFlightSource("Mumbai");
		flight3.setFlightDestination("New York");
		
		listOfFlights.add(flight1);
		listOfFlights.add(flight2);
		listOfFlights.add(flight3);
	}
	
	//http://localhost:8080/OnlineAirlines/controller/flights
	@RequestMapping(value="/flights",method=RequestMethod.GET)
	public @ResponseBody List<Flight>  getFlightList()  {
		
		return listOfFlights;
	
	}
	
	// http://localhost:8080/OnlineAirlines/controller/allflights/103
	@RequestMapping(value="/allflights/{flno}",method=RequestMethod.GET)
	public @ResponseBody Flight  getFlight(@PathVariable("flno") int flightNumber)  {
		
		for (Flight flight : listOfFlights) {
			if(flight.getFlightNumber() == flightNumber) {
				return flight;
			}
		}
		return null;
	}
}
