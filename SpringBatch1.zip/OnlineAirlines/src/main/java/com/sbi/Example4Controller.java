package com.sbi;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.InternalResourceView;

			//CONTROLLER
@Controller
public class Example4Controller {
	
	
	@RequestMapping("/example4.do")
	public String anyMethodName(Map model)  {
		
		model.put("mymessage","Welcome to Spring MVC Controller3");//MODEL
		return "example1"; //RETURNING A VIEW - with a View Class
			//auto pickup the example1.jsp file
	}
}
