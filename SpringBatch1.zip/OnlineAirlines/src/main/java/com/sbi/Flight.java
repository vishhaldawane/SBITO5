package com.sbi; //1

import javax.xml.bind.annotation.XmlRootElement;

//@XmlRootElement
public class Flight { //2
	
	private int flightNumber; //3
	private String flightName;
	private String flightSource;
	private String flightDestination;
	
	//4
	public Flight() {
		super();
		// TODO Auto-generated constructor stub
	}

	//5
	
	public int getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public String getFlightSource() {
		return flightSource;
	}

	public void setFlightSource(String flightSource) {
		this.flightSource = flightSource;
	}

	public String getFlightDestination() {
		return flightDestination;
	}

	public void setFlightDestination(String flightDestination) {
		this.flightDestination = flightDestination;
	}

	@Override
	public String toString() {
		return "Flight [flightNumber=" + flightNumber + ", flightName=" + flightName + ", flightSource=" + flightSource
				+ ", flightDestination=" + flightDestination + "]";
	}
	
	
	
	
	
	
}
