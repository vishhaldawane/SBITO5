package com.sbi;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.TreeMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FlightStatusController
 */
@WebServlet("/findFlightStatus")
public class FlightStatusController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	TreeMap<String,String> treeMap = new TreeMap<String,String>();
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FlightStatusController() {
        super();
        // TODO Auto-generated constructor stub
        treeMap.put("123123", "Flight is confirmed");
        treeMap.put("123223", "Flight is NOT confirmed");
        treeMap.put("123323", "Flight is delayed");
        treeMap.put("123423", "Flight is cancelled");
        treeMap.put("123523", "Flight is rescheduled");
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String flightPnr = request.getParameter("fli_pnr");
		PrintWriter pw = response.getWriter();
		//following lines are MIXTURE OF MODEL AND VIEW
		
		String status = null;
		if(treeMap.containsKey(flightPnr)) {
			status = treeMap.get(flightPnr);
		}
		
		pw.println("<table border=5 cellspacing=10 cellpadding=10>");
			pw.println("<tr>");
				pw.println("<td>Flight Status of PNR : "+flightPnr+"</td>");
			pw.println("</tr>");
			
			pw.println("<tr>");
				pw.println("<td>"+status+"</td>");
			pw.println("</tr>");
		pw.println("</table>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
