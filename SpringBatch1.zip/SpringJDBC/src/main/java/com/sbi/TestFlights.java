package com.sbi;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestFlights {
	public static void main(String[] args) {
		
		
		System.out.println("creating container...");		
		ApplicationContext myContext = new ClassPathXmlApplicationContext("myspring.xml");
		System.out.println("container...created");
		
		FlightRepository flightRepo = (FlightRepository ) myContext.getBean(FlightRepository.class);
		/*List<Flight> listOfFlights = flightRepo.getAvailableFlights();
		
		for (Flight flight : listOfFlights) {
			System.out.println(flight);
		}*/
		
		Flight theFlight;
		try {
			theFlight = (Flight) flightRepo.findFlight(106);
			System.out.println("The flight : "+theFlight);

		} catch (FlightNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("ERR : "+e.getMessage());
		}
		
		
		
		
		
	}
}
