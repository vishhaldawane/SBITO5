package com.sbi.repository;


import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.sbi.entity.Flight;
import com.sbi.myexceptions.FlightNotFoundException;

@Service
public interface FlightRepository {
	public void addFlight(Flight theFlight);    //C
	public List<Flight>	getAvailableFlights();  //RA
	public Flight findFlight(int flightNumber) throws FlightNotFoundException; //R
	public void updateFlight(Flight theFlight); //U
	public void deleteFlight(Flight theFlight); //D
}
