package com.sbi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.entity.Flight;
import com.sbi.myexceptions.FlightNotFoundException;

@Service
public interface FlightService {
	public void saveFlightService(Flight theFlight);    
	public List<Flight>	findAvailableFlightsService();  
	public Flight findSingleFlightService(int flightNumber) throws FlightNotFoundException; 
	public void modifyFlightService(Flight theFlight); 
	public void removeFlightService(Flight theFlight); 
}



