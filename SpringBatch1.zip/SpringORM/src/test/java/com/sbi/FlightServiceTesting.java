package com.sbi;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.entity.Flight;
import com.sbi.myexceptions.FlightNotFoundException;
import com.sbi.service.FlightService;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations= {"classpath:myspring.xml"} )
public class FlightServiceTesting {

	@Autowired
	FlightService flightService;
	
	@Test
	public void findFlightServiceTest() {
		
		try {
			Flight flight = flightService.findSingleFlightService(101);
			System.out.println("flight : "+flight);
		} catch (FlightNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
}
