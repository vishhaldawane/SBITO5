package com.sbi.layer3;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

//create table tx_products (productid int, quantity int);
//insert into  tx_products values (123,9999);

@Repository
public class ProductRepositoryImpl implements ProductRepository {
	@Autowired	JdbcTemplate jdbcTemplate;
	public ProductRepositoryImpl() {System.out.println("ProductRepositoryImpl() ctor...");	}
	
	@Transactional
	public void reduceStock(int productId, int quantity) {
		String queryToRun = "update tx_prodcts set quantity = quantity - ?"
							+ " where productId=?";
		System.out.println("JDBC : "+queryToRun); //BAD way to show the query log
		jdbcTemplate.update(queryToRun, quantity, productId);
	}
}
