package com.sbi.layer4;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.sbi.layer2.Order;

@Service
public interface OnlineShoppingService {
	@Transactional
	public void placeOrder(Order order);
}
