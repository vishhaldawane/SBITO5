package com.sbi.layer4;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sbi.layer2.Order;
import com.sbi.layer2.Payment;
import com.sbi.layer3.OrderRepository;
import com.sbi.layer3.PaymentRepository;
import com.sbi.layer3.ProductRepository;

@Service
public class OnlineShoppingServiceImpl implements OnlineShoppingService {

	@Autowired 	private OrderRepository orderRepository;
	@Autowired 	private PaymentRepository paymentRepository;
	@Autowired 	private ProductRepository productRepository;
	
	@Transactional
	public void placeOrder(Order order) {
		
		orderRepository.processOrder(order); //1. STORE THE ORDER INFORMATION
		
		Payment newPaymentDetails = new Payment(); //PROCESS THE NEW PAYMENT DETAILS
		newPaymentDetails.setOrderId(order.getOrderId());
		newPaymentDetails.setAmount(order.getQuantity() * order.getPrice());
		paymentRepository.store(newPaymentDetails); //2. STORE THE NEW PAYMENT DETAILS
		
		//3. UPDATE THE STOCK
		productRepository.reduceStock(order.getProductId(), order.getQuantity());
	}
}

interface A
{
	void fun();
}

interface B
{
	void fun();
}

class C implements A,B
{
	public void fun() {
		
	}
}






