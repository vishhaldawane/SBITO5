import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.layer2.Order;
import com.sbi.layer4.OnlineShoppingService;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations= {"classpath:myspring.xml"} )
public class TransactionTest {

	@Autowired
	private OnlineShoppingService onlineShopping;
	
	
	@Test
	public void textTransaction() {
		
		System.out.println("CREATING A NEW ORDER...");
		Order newOrder = new Order();
		newOrder.setProductId(123);
		System.out.println("NEW ORDER'S PRODUCT IS SET...");
		
		newOrder.setPrice(1000);
		System.out.println("NEW ORDER'S PRICE IS SET...");
		
		newOrder.setQuantity(3);
		System.out.println("NEW ORDER'S QTY IS SET...");
		
		System.out.println("PLACING THE ORDER....");
		onlineShopping.placeOrder(newOrder);
	}
			
			
	
}
