package com.sbi.demo;

import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.demo.layer2.Friend;
import com.sbi.demo.layer3.FriendRepository;
import com.sbi.demo.layer4.FriendService;

@SpringBootTest
class DemoApplicationTests {

	
	@Autowired
	FriendRepository friendRepo;
	
	@Autowired
	FriendService friendService;
	
	@Test
	void loadAllFriendViaRepoTest() {
		
		 Iterable<Friend> iter = friendRepo.findAll();
		 Iterator<Friend> friendIter = iter.iterator();
		 
		 
		 while(friendIter.hasNext()) {
			 Friend friend = friendIter.next();
			 System.out.println("Friend : "+friend);
		 }
		
	}
	
	@Test
	void loadAllFriendViaServiceTest() {
		
		List<Friend> listOfFriends = friendService.getAllFriendsService();
		for (Friend friend : listOfFriends) {
			System.out.println("FRIEND : "+friend);
		}
		
	}


}
