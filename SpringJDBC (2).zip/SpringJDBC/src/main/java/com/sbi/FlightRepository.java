package com.sbi;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public interface FlightRepository {
	public void addFlight(Flight theFlight);    //C
	public List<Flight>	getAvailableFlights();  //RA
	public Flight findFlight(int flightNumber) throws FlightNotFoundException; //R
	public void updateFlight(Flight theFlight); //U
	public void deleteFlight(Flight theFlight); //D
}
