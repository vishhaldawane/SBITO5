package com.sbi;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public interface FlightRepository {
	public List<Flight>	getAvailableFlights(); 
}
