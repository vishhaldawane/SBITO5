package com.sbi;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class FlightRepositoryImpl implements FlightRepository {

	//@Autowired
	DataSource dataSource;
	
	@Autowired
	@Qualifier("myds4hsql")
	public void setDataSource(DataSource ds) {
		System.out.println("setDataSource(DataSource) invoked...");
		dataSource = ds;
	}
	
	public List<Flight> getAvailableFlights() {
	
		List<Flight> theFlightList = new ArrayList<Flight>();
		
		try {
			Connection conn = dataSource.getConnection();
			
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM FLIGHTS");
			
			while(rs.next()) {
				Flight theFlight = new Flight();
				theFlight.setFlightNumber(rs.getInt(1));
				theFlight.setFlightName(rs.getString(2));
				theFlight.setFlightSource(rs.getString(3));
				theFlight.setFlightDestination(rs.getString(4));
				
				theFlightList.add(theFlight);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return theFlightList;
	}

}
