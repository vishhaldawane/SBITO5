package com.sbi;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component     // ORM way - CMP
public class FlightRepositoryImpl implements FlightRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	public FlightRepositoryImpl() {
		System.out.println("FlightRepositoryImpl() ctor....");
	}
	
	public List<Flight> getAvailableFlights() {
	
		List<Flight> theFlightList = null;
													//JPQL
		theFlightList = entityManager.createQuery("from Flight").getResultList();
		
		return theFlightList;
	}

	
	@Transactional
	public void addFlight(Flight theFlight) {
		System.out.println("ADDING THE FLIGHT....");
	//	EntityTransaction entityTrans = entityManager.getTransaction();
		System.out.println("Acquiring the Transaction manager...");
		
	//	entityTrans.begin();
	//	System.out.println("Transction started....");
			entityManager.persist(theFlight);
	//	entityTrans.commit();
	//	System.out.println("Transction committed......");
		
		
	}

	@Override
	public Flight findFlight(int flightNumber) throws FlightNotFoundException 
	{
		return 	entityManager.find(Flight.class,flightNumber);
	}

	@Transactional
	public void updateFlight(Flight theFlight) {
		// TODO Auto-generated method stub
		entityManager.merge(theFlight);
		System.out.println("flight updated...");
	}

	@Transactional
	public void deleteFlight(Flight theFlight) {
		// TODO Auto-generated method stub
		Flight flight = entityManager.find(Flight.class, theFlight.getFlightNumber());
		entityManager.remove(flight);
		System.out.println("flight deleted.....");
		
		
	}

}
