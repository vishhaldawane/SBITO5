package com.sbi;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations= {"classpath:myspring.xml"} )
public class FlightTestCases {
	
	
	@Autowired
	FlightRepository flightRepo;
	
	@Test //add the junit 5 library 
	public void findFlightTest() {
		
		try {
			Flight foundFlight = (Flight) flightRepo.findFlight(101);
			System.out.println("flight : "+foundFlight);
		} catch (FlightNotFoundException e) {

			System.out.println(e.getMessage());
		}
		
	}
	
	@Test //add the junit 5 library 
	public void addFlightTest() {

			Flight theNewFlight = new Flight();
			theNewFlight.setFlightNumber(107);
			theNewFlight.setFlightName("Nepal Airlines");
			theNewFlight.setFlightSource("Mumbai");
			theNewFlight.setFlightDestination("Kathmandu");			
			
			flightRepo.addFlight(theNewFlight);
	}
	
	
}
