package com.sbi;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sbi.entity.Flight;
import com.sbi.myexceptions.FlightNotFoundException;
import com.sbi.repository.FlightRepository;

public class TestFlights {
	public static void main(String[] args) {
		
		
		System.out.println("creating container...");		
		ApplicationContext myContext = new ClassPathXmlApplicationContext("myspring.xml");
		System.out.println("container...created");
		
		FlightRepository flightRepo = (FlightRepository ) myContext.getBean(FlightRepository.class);
		/*List<Flight> listOfFlights = flightRepo.getAvailableFlights();
		
		for (Flight flight : listOfFlights) {
			System.out.println(flight);
		}*/
		
		/*Flight theNewFlight = new Flight();
		theNewFlight.setFlightNumber(106);
		/*theNewFlight.setFlightName("Emirates");
		theNewFlight.setFlightSource("Mumbai");
		theNewFlight.setFlightDestination("Kuwait");*/
		
		/*flightRepo.deleteFlight(theNewFlight);*/
		
		try {
			Flight foundFlight = (Flight) flightRepo.findFlight(101);
			System.out.println("flight : "+foundFlight);
		} catch (FlightNotFoundException e) {

			System.out.println(e.getMessage());
		}
		
		
		
		

	}
}
