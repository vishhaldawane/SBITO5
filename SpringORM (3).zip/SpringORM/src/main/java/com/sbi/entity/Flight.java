package com.sbi.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id; //JPA
import javax.persistence.Table;

@Entity // the class which has primary key is known as entity
@Table(name="flights")
public class Flight { //2
	
	//4
	public Flight() {
		System.out.println("> POJO <");
		System.out.println("Creating a flight bean...");
		System.out.println("> POJO <");
	}
	
	@Id
	@Column(name="FLIGHTNUMBER")
	private int flightNumber; //3
	
	@Column(name="FLIGHTNAME")
	private String flightName;
	
	@Column(name="FLIGHTSOURCE")
	private String flightSource;
	
	@Column(name="FLIGHTDEST")
	private String flightDestination;
	
	

	//5
	
	public int getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public String getFlightSource() {
		return flightSource;
	}

	public void setFlightSource(String flightSource) {
		this.flightSource = flightSource;
	}

	public String getFlightDestination() {
		return flightDestination;
	}

	public void setFlightDestination(String flightDestination) {
		this.flightDestination = flightDestination;
	}

	@Override
	public String toString() {
		return "Flight [flightNumber=" + flightNumber + ", flightName=" + flightName + ", flightSource=" + flightSource
				+ ", flightDestination=" + flightDestination + "]";
	}
	
	
	
	
	
	
}
