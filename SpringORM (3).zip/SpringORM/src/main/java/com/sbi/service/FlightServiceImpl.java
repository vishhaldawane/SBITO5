package com.sbi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.entity.Flight;
import com.sbi.myexceptions.FlightNotFoundException;
import com.sbi.repository.FlightRepository;

@Service
public class FlightServiceImpl implements FlightService {
	
	@Autowired	FlightRepository flightRepo;
	
	//A service function invoking a repository function
		public Flight findSingleFlightService(int flightNumber) throws FlightNotFoundException {
			System.out.println("\t\t>>> BUSINESS LOGIC SERVICE <<<");
			Flight foundFlight = flightRepo.findFlight(flightNumber);
			
			if(foundFlight==null) {
				FlightNotFoundException flightNotFoundEx = new FlightNotFoundException("Flight not found : "+flightNumber);
				throw flightNotFoundEx;
			}
			System.out.println("\t\t>>> BUSINESS LOGIC SERVICE <<<");
			return foundFlight;
		}
		
		
	public void saveFlightService(Flight theFlight) {
		// TODO Auto-generated method stub

	}

	
	public List<Flight> findAvailableFlightsService() {
		// TODO Auto-generated method stub
		return null;
	}

	

	
	public void modifyFlightService(Flight theFlight) {
		// TODO Auto-generated method stub

	}

	public void removeFlightService(Flight theFlight) {
		// TODO Auto-generated method stub

	}

}
