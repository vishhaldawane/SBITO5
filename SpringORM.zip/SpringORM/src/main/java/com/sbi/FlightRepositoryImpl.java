package com.sbi;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component     // ORM way - CMP
public class FlightRepositoryImpl implements FlightRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	public FlightRepositoryImpl() {
		System.out.println("FlightRepositoryImpl() ctor....");
	}
	
	public List<Flight> getAvailableFlights() {
	
		List<Flight> theFlightList = null;
													//JPQL
		theFlightList = entityManager.createQuery("from Flight").getResultList();
		
		return theFlightList;
	}

	@Override
	public void addFlight(Flight theFlight) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Flight findFlight(int flightNumber) throws FlightNotFoundException 
	{
		
		return null;
	}

	@Override
	public void updateFlight(Flight theFlight) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteFlight(Flight theFlight) {
		// TODO Auto-generated method stub
		
	}

}
