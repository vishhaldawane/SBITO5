package com.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.java.repository.UserRepository;

@SpringBootApplication
@EnableJpaRepositories(basePackageClasses = UserRepository.class)
public class SpringSecurity3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurity3Application.class, args);
		System.out.println("Spring Web Security App started....");
	}

}
// localhost:8080


/*


					SpringSecurity-3
							|
			--------------------------------------------------------
			|			|			|			|3		|2		|1
			controller	config		service	repository	pojo	db
			|			|			|				 |
		UserResource   MySecurity	|				 |
		/			   Configuration|				 |
		/user				|		|				 |
		/admin  			+--->UserDetailsService-->
									|
							MyUserDetailsService <-- implementation of above interface
									|
				UserDetails loadUserByUsername(userName)
				|
		MyUserDetails <-implementation
		 
			
			



*/