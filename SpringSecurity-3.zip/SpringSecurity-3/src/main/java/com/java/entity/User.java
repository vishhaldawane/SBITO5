package com.java.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
/*
 create table user
 (
    id int primary key,
    user_name varchar(50),
    password varchar(200),
    active boolean,
    roles varchar(20)
 );
 
 interface UserRepository {
 	void selectUser(int id);
 	List<User> selectUsers();
 	void insertUser(User u);
 	void updateUser(User u);
 	void deleteUser(int id);
 }
 class BaseRepository {
 	
 	@PersistenceContext;
 	EntityManager em;
 	
 	public void persist(Object o) {
 		em.persist(o);
 	}
 }
 class UserRepositoryImpl extends BaseRepository implements UserRepository
 {
 
 }
 
 OR
 
 JpaRepository
 
 interface UserRepository extends JpaRepository
 {
 
 }
 
 */
@Entity
@Table(name="user")
public class User { //localhost:8080

	@Id
	@GeneratedValue
	private int id;
	
	//@Column(name="username")
	private String userName; // user_name in db
	private String password; // password in db
	private boolean active; // active in db
	private String roles; // roles in db
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public String getRoles() {
		return roles;
	}
	public void setRoles(String roles) {
		this.roles = roles;
	}
	
	
}
