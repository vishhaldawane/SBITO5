package com.java.service;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.java.entity.User;

public class MyUserDetails implements UserDetails
{
	private String userName;
	private String password;
	private boolean active;
	private List<GrantedAuthority> authorities;
	
	public MyUserDetails() {
		System.out.println("MyUserDetails()...no arg constructor....");
	}
	//import org.springframework.security.core.authority.SimpleGrantedAuthority;

	MyUserDetails(User user) {
		System.out.println("MyUserDetails: MyUserDetails(User)");

		this.userName = user.getUserName();
		this.password = user.getPassword();
		this.active = user.isActive();
		System.out.println(">"+user.getRoles());
		
//		System.out.println(">> "+user.getRoles().split(","));
		this.authorities = Arrays.stream(user.getRoles().split(","))
		.map(SimpleGrantedAuthority::new)
		.collect(Collectors.toList());
		
		// 1. user.getRoles() -> String roles="USER,ENDUSER,POWERUSER,ADMIN,SALESMAN,ACCOUNTANT";
		// 2. .split(",")     -> String roles=[] = { "USER","ADMIN","SALESMAN","ACCOUNTANT"}
		// 3. Arrays.stream(); -> stream of strings ....
		// 4. map() -> convert this string tokens as SimpleGrantedAuthority tokens
		// 5. collect() to convert above tokens as a List
		
		//SimpleGrantedAuthority
		
		
		//List | Set
		
		//youtube - watching  a video
		// 1 gb 100 mnts	20th   60th  		90th minute
	}


	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		System.out.println("MyUserDetails: getAuthorities()");
		return authorities;
	}


	@Override
	public String getPassword() {
		System.out.println("MyUserDetails: getPassword()");
		return password;
	}


	@Override
	public String getUsername() {
		System.out.println("MyUserDetails: getUsername()");
		return userName;
	}


	@Override
	public boolean isAccountNonExpired() {
		System.out.println("MyUserDetails: isAccountNonExpired()");
		return true;
	}


	@Override
	public boolean isAccountNonLocked() {
		System.out.println("MyUserDetails: isAccountNonLocked()");
		return true;
	}


	@Override
	public boolean isCredentialsNonExpired() {
		System.out.println("MyUserDetails: isCredentialsNonExpired()");
		return true;
	}


	@Override
	public boolean isEnabled() {
		System.out.println("MyUserDetails: isEnabled()");
		//GrantedAuthority ta = this.authorities.get(0);
		//String str = ta.getAuthority();
		 /*active=false;
		if(str.equals("ROLE_ADMIN"))
			active=true;
		else
			active=false;*/
		
		return active;
	}
	
	
}
/*
 public class MyUserDetails implements UserDetails{
 

	private String userName;
	
	MyUserDetails(String username) {
		userName=username;
		System.out.println("MyUserDetails(String username)");

	}
	MyUserDetails() {
		System.out.println("MyUserDetails()");
	}
	
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		System.out.println("MyUserDetails: getAuthorities()");
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_USER"));
	}

	@Override
	public String getPassword() {
		System.out.println("MyUserDetails: getPassword()");
		return "mypassword";
	}

	@Override
	public String getUsername() {
		System.out.println("MyUserDetails: getUsername()");
		return userName;
	}

	@Override
	public boolean isAccountNonExpired() {
		System.out.println("MyUserDetails: isAccountNonExpired()");

		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		System.out.println("MyUserDetails: isAccountNonLocked()");

		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		System.out.println("MyUserDetails: isCredentialsNonExpired()");
		return true;
	}

	@Override
	public boolean isEnabled() {
		System.out.println("MyUserDetails: isEnabled()");
		return true;
	}

}
*/
