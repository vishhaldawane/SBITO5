package com.java.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.java.entity.User;
import com.java.repository.UserRepository;


@Service //("uds2")
public class MyUserDetailsService implements UserDetailsService{

	@Autowired
	UserRepository userRepository;//spring would give us the implementation of this
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		System.out.println("MyUserDetailsService: loadUserByUsername(String username) invoked...."+username);
		//return new MyUserDetails(username); //first version
		
		//now the second version - UserRepository (JpaRepository) way 
		Optional<User> user =  userRepository.findByUserName(username);
		
		//user.orElseThrow(()-> new
			//	UsernameNotFoundException(">> not found : "+username));
		
		return user.map(MyUserDetails::new).get();
	}

	
}
/*
interface UD // UserDetails - Account
{
	
}
class UDImpl implements UD //isA UD - SavingsAccount
{
	
}
class UDImpl2 implements UD //isA UD - CurrentAccount
{
	
}
class UDImpl3 implements UD //isA UD - CreditAccount
{
	
}
interface UDS //UserDetailsService
{
	UD fun() ;
	
}

class UDSImpl implements UDS
{
	public UDImpl fun() {
		//UDImpl u = new UDImpl();
		//UDImpl2 u = new UDImpl2();
		UDImpl3 u = new UDImpl3();
		return u;
	}
}
*/

