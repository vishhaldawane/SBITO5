package com.sbi.layer3;

import org.springframework.stereotype.Repository;

import com.sbi.layer2.Order;

@Repository
public interface OrderRepository {
	void processOrder(Order orderObj);
}
