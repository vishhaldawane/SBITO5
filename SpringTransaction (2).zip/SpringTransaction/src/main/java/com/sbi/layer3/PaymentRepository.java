package com.sbi.layer3;

import org.springframework.stereotype.Repository;

import com.sbi.layer2.Payment;

@Repository
public interface PaymentRepository {
	void store(Payment paymentDetails);
}
