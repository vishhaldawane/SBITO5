package com.sbi.layer3;

import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepository {
	void reduceStock(int productId, int quantity);
}
