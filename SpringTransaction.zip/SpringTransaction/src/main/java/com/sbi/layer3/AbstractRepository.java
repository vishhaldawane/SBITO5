package com.sbi.layer3;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public abstract class AbstractRepository {
	@PersistenceContext
	private EntityManager entityManager;
	public EntityManager getEntityManager() {		return entityManager;	}
}
