package com.sbi.layer3;

import com.sbi.layer2.Order;

public interface OrderRepository {
	void processOrder(Order orderObj);
}
