package com.sbi.layer3;

import javax.transaction.Transactional;

import com.sbi.layer2.Order;
public class OrderRepositoryImpl extends AbstractRepository implements OrderRepository {
	@Transactional
	public void processOrder(Order orderObj) {
		System.out.println("> Order being processed....");
			getEntityManager().persist(orderObj);
		System.out.println("> Order is processed....");
	}

}
