package com.sbi.layer3;

import com.sbi.layer2.Payment;

public interface PaymentRepository {
	void store(Payment paymentDetails);
}
