package com.sbi.layer3;

import javax.transaction.Transactional;

import com.sbi.layer2.Payment;

public class PaymentRepositoryImpl extends AbstractRepository implements PaymentRepository {
	@Transactional
	public void store(Payment paymentDetails) {
		System.out.println(">> Payment being processed....");
			getEntityManager().persist(paymentDetails);
		System.out.println(">> Payment is processed....");
	}

}
