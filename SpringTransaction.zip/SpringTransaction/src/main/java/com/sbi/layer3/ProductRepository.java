package com.sbi.layer3;

public interface ProductRepository {
	void reduceStock(int productId, int quantity);
}
