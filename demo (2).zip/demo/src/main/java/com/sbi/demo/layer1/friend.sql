create table friends
(
   friendId int primary key,
   friendName varchar(20),
   friendType varchar(20)
);

insert into friends values (1,'Deven','mutual');
insert into friends values (2,'Samir','school');
insert into friends values (3,'Priya','college');
insert into friends values (4,'Jayant','office');
insert into friends values (5,'YouAll','batch');
