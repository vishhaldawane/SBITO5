package com.sbi.demo.layer5;

import java.util.List;

/*
 * SDLC  / AGILE
 * 
 * 1 db to be tested
 * 2 pojo to be verified
 * 3 repos to be tested
 * 4 service to be tested
 * 5 controller to be tested
 * 6 UI to be tested
 * 
 * 
 * 
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.demo.layer2.Friend;
import com.sbi.demo.layer4.FriendService;

@RestController

// http://localhost:8080/friendapp
@RequestMapping("/friendapp")
public class FriendController {

	public FriendController() {
		System.out.println("FriendController() ctor...");
	}

	@Autowired
	FriendService friendService;

	// http://localhost:8080/friendapp/friends
	@GetMapping("/friends")
	public List<Friend> getAllFriends() {
		System.out.println("getAllFriends() invoked...");
		return friendService.getAllFriendsService();
	}

	// http://localhost:8080/friendapp/friends
	@GetMapping("/friends/{fid}")
	public Friend getAFriend(@PathVariable("fid") int friendId) {
		System.out.println("getAFriend() invoked...");
		return friendService.getAFriendService(friendId); 
	}

	// http://localhost:8080/friendapp/friends
	@PostMapping("/addFriend")
	public Friend addAFriend(@RequestBody Friend friendObject) {
		System.out.println("addAFriend() invoked...");
		friendService.addAFriendService(friendObject);
		return friendObject;
	}
	
	// http://localhost:8080/friendapp/friends
	@PutMapping("/updateFriend")
	public Friend updateAFriend(@RequestBody Friend friendObject) {
		System.out.println("updateAFriend() invoked...");
		friendService.updateAFriendService(friendObject);
		return friendObject;
	}

	// http://localhost:8080/friendapp/friends
	@DeleteMapping("/deleteFriend")
	public Friend deleteAFriend(@RequestBody Friend friendObject) {
		System.out.println("deleteAFriend() invoked...");
		friendService.deleteAFriendService(friendObject);
		return friendObject;
	}
}
