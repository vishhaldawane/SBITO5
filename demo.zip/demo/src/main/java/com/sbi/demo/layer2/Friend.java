package com.sbi.demo.layer2;




import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="friends")
@Getter
@Setter
public class Friend {

	@Id
	@GeneratedValue
	@Column(name="friendid")
	private int friendNumber;
	
	@Column(name="friendname")
	private String friendName;
	
	@Column(name="friendtype")
	private String friendType;

	@Override
	public String toString() {
		return "Friend [friendNumber=" + friendNumber + ", friendName=" + friendName + ", friendType=" + friendType
				+ "]";
	}

	public int getFriendNumber() {
		return friendNumber;
	}

	public void setFriendNumber(int friendNumber) {
		this.friendNumber = friendNumber;
	}

	public String getFriendName() {
		return friendName;
	}

	public void setFriendName(String friendName) {
		this.friendName = friendName;
	}

	public String getFriendType() {
		return friendType;
	}

	public void setFriendType(String friendType) {
		this.friendType = friendType;
	}
	
	
}
