package com.sbi.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.demo.layer2.Friend;

@Service
public interface FriendService {
	List<Friend> getAllFriendsService();
}
