package com.sbi.demo.layer4;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.demo.layer2.Friend;
import com.sbi.demo.layer3.FriendRepository;

@Service
public class FriendServiceImpl implements FriendService {

	@Autowired
	FriendRepository friendRepo;
	
	@Override
	public List<Friend> getAllFriendsService() {
		System.out.println(">> SERVICE ");
		List<Friend> friendList = new ArrayList<Friend>();
		
		Iterable<Friend> iter = friendRepo.findAll();
		 Iterator<Friend> friendIter = iter.iterator();
		 
		 while(friendIter.hasNext()) {
			 Friend friend = friendIter.next();
			 System.out.println("Friend : "+friend);
			 friendList.add(friend);
		 }
		 System.out.println(">> SERVICE ");
		 return friendList;
	}

}
