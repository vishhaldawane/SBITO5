package com.sbi.demo.layer5;


import java.util.List;

/*
 * SDLC  / AGILE
 * 
 * 1 db to be tested
 * 2 pojo to be verified
 * 3 repos to be tested
 * 4 service to be tested
 * 5 controller to be tested
 * 6 UI to be tested
 * 
 * 
 * 
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.demo.layer2.Friend;
import com.sbi.demo.layer4.FriendService;

@RestController
public class FriendController {
	
	public FriendController() {
		System.out.println("FriendController() ctor...");
	}
	@Autowired
	FriendService friendService;
	
	@GetMapping("friends")
	public List<Friend> getAllFriends() {
		System.out.println("getAllFriends() invoked...");
		return friendService.getAllFriendsService();
	}

}
